package com.tarpuq.transfers_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransfersServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
